This captive portal was forked from https://github.com/braindead-sec/rogue-captive. 

Which is still, upon time of writing, missing a LICENSE file.

Please contact me in case of takedown request.
